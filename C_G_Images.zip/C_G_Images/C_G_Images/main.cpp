//
//  main.cpp
//  C_G_Images
//
//  Created by Edson  Jr on 21/10/16.
//  Copyright © 2016 Edson  Jr. All rights reserved.
//
//


#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <vector>
#include <string.h>
#include <fstream>
#include <opencv2/opencv.hpp>
#include <opencv/cv.h>
#include <opencv2/highgui.hpp>
#include <opencv2/ml.hpp>

using namespace std;
using namespace cv;

vector<string> pathsDasImagens;
vector<string> nomeDasImagens;

void C_G_Face(const char *pathDaImagem,const char *nomeImagem,int modo);
void carregarArquivo(const char* nomeArquivo);
void visualizarArquivo();
void executarCGFaces(int modo, int incremento);



int main(int argc, const char * argv[]) {
   
    //verificando se foi passado algum parametro para o programa
    if(argc < 3){ // o proprio nome do programa em linha de comando corresponde ao argc == 1
        cout <<"Error: Necessario informar um arquivo texto com paths das imagens e um modo.  \n";
      
        exit(-1);
    }
    
    int modo = atoi(argv[2]);
    carregarArquivo(argv[1]);
    
    
    //executando
    executarCGFaces(modo, 0);
    
    
        return 0;
}







/********************************************************************
 *                  SECAO DAS FUNCOES                               *
 ********************************************************************/
void C_G_Face(const char *pathDaImagem,const char *nomeImagem,int modo){
    /*Esta funcao tem como objetivo carregar uma imagem (o path dela é passado como argumento), verificar se ela e valida, verificar se ha rostos nessa imagem,
        realizar a deteccao facial, permitir recortar a imagem no rosto, redimensionar
        a imagem, colocar em escala de cinza e por fim salvar*/
    
    
    //carregando imagem
    Mat img;
    img = imread(pathDaImagem, CV_LOAD_IMAGE_COLOR);
    
    //carregando e verificando o face cascade
    String cascadeClassifierName = "/usr/local/Cellar/opencv/2.4.13_3/share/OpenCV/haarcascades/haarcascade_frontalface_alt2.xml";
    CascadeClassifier face_cascade;
    if(!face_cascade.load(cascadeClassifierName)){
        cout << "FATAL ERROR: Nao foi possivel carregar cascade xml files. Abortando... \n";
        cout << face_cascade.empty() << "\n";
        exit(-1);
    }

    
    //verificando se a imagem nao encontra - se vazia
    if(img.empty()){
        cout << "ERROR: Sem dados de imagem... \n";
        cout << ">> " << pathDaImagem <<" <<\n";
        return;
    }else {
        cout << "Input: " << pathDaImagem <<"\n";
    }

    
    //detectando faces
    vector<Rect> faces;
    face_cascade.detectMultiScale(img, faces, 1.1, 2, 0|CV_HAAR_SCALE_IMAGE, Size(64, 64));
    
    //realizando processamento somente se existirem faces na foto.
    if (faces.size() != 0) {
        Mat cropImg;
        for( int i = 0; i < faces.size(); i++ )
        {
            Point center( faces[i].x + faces[i].width*0.5, faces[i].y + faces[i].height*0.5 );
            cropImg = img(Rect(faces[i].x,faces[i].y,faces[i].width,faces[i].height));
        }
        
        if(cropImg.empty()){
            cout << "ERROR: Imagem vazia de output gerada. Sem dados a serem salvos...";
            return;
        }else {
            
            Mat outputGrayImage; //imagem de saida que será salva
            cvtColor(cropImg, outputGrayImage, CV_BGR2GRAY);
            
            Mat resizedImg; //ira armazenar a imagem redimensionada
            
            //redimensionando a imagem
           
            cout <<"Escolhido: " << modo;
            
            if(modo == 1){
                cout <<" - Salvando em 24x24 \n";
                Size size(24,24);
                resize(outputGrayImage, resizedImg, size);
                imwrite(nomeImagem, resizedImg); //salvando a imagem redimensionada e em grayscale no disco
            }else if (modo == 2){
                cout <<" - Salvando em 32x32 \n";
                Size size(32,32);
                resize(outputGrayImage, resizedImg, size);
                imwrite(nomeImagem, resizedImg); //salvando a imagem redimensionada e em grayscale no disco
            }else if (modo == 3){
                cout <<" - Salvando em 64x64 \n";
                Size size(64,64);
                resize(outputGrayImage, resizedImg, size);
                imwrite(nomeImagem, resizedImg); //salvando a imagem redimensionada e em grayscale no disco
            }else if (modo == 4){
                cout <<" - Salvando em 128x128 \n";
                Size size(128,128);
                resize(outputGrayImage, resizedImg, size);
                imwrite(nomeImagem, resizedImg); //salvando a imagem redimensionada e em grayscale no disco
            }else {
                cout <<" - Salvando em 16x16 - DEFAULT \n";
                Size size(16,16);
                resize(outputGrayImage, resizedImg, size);
                imwrite(nomeImagem, resizedImg); //salvando a imagem redimensionada e em grayscale no disco
            }
            imshow("img", resizedImg);
            
            /*MELHORAR ALGORITMO PARA DETECTAR SE FOI INFORMADO ALGUMA EXTENSAO PARA
             A IMAGEM DE SAIDA*/
        }
        
        
    }else{
        cout <<">>ATENCAO: sem faces nesta foto ou nao detectado...\n";
        return;
    }

    
    
    
}


void carregarArquivo(const char* nomeArquivo){
    /*Esta funcao e responsavel por carregar o arquivo passado como parametro para o programa, alem de salvar os paths dos arquivos e o nome dos arquivos em  duas listas diferentes*/
    
   
   
    
    string txtLine;
    string filename;
    ifstream myfile(nomeArquivo); //abrindo arquivo
   
    if(myfile.is_open()){ //verificando se o arquivo esta aberto
        
        while (!myfile.eof()) { //enquanto nao chegar no fim do arquivo, percorra suas linhas
            getline(myfile,txtLine); //lendo uma linha do arquivo de texto
            pathsDasImagens.push_back(txtLine); //colocando cada linha do arquivo no vetor
            int pos = txtLine.find_last_of("/"); //pegando a posicao de onde inicia o nome do arquivo
            filename = txtLine.substr(pos+1);
            nomeDasImagens.push_back(filename); //salvando o nome dos arquivos no vetor
        }
        
        cout <<"Arquivo com: " << pathsDasImagens.size() <<" paths \n";
         visualizarArquivo();
        
    }else{
        cout <<"Falha ao abrir arquivo \n";
        exit(-1);
    }
    
}



void executarCGFaces(int modo, int incremento) {
    /*Este metodo tem o objetivo de chamar a funcao para identificar as faces e fazer o processamento de imagem. Cada chamada sera feita de acordo com um valor dos 
        arrays onde se armazena os paths das imagens carregadas do arquivo*/
    
    if(incremento >= pathsDasImagens.size()-1){
        cout <<"Processo terminado... \n\n";
        return;
    }
    
    const char *path = pathsDasImagens.at(incremento).c_str();
    string predicado = "out_";
    predicado.append(nomeDasImagens.at(incremento));
    const char *nome = predicado.c_str();
    
    C_G_Face(path, nome, modo);
    
    //recursividade
    executarCGFaces(modo,++incremento);
}


void visualizarArquivo() {
    /*Simplesmente lista o conteudo do arquivo que foi carregado para os vetores*/
    cout<<"Conteudo do arquivo: \n";
    for(int i = 0; i < pathsDasImagens.size();i++){
        cout << pathsDasImagens.at(i) <<"\n";
    }
}








