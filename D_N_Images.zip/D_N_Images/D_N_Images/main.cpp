//
//  main.cpp
//  D_N_Images
//
//  Created by Edson  Jr on 04/11/16.
//  Copyright © 2016 Edson  Jr. All rights reserved.
//

#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <sstream>
#include <opencv/cv.h>
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/ml.hpp>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;

const char *usage = "\n\nUso: \n"
                    " <path_img_orig>  <qtCopias>  <tipoFiltro>  <predicadoSaida> \n"
                    " Tipos de Filtro \n"
                    "[0] - imagem original \n"
                    "[1] - MedianBlur \n"
                    "[2] - BilateralBlur \n"
                    "[3] - HomogeneosBlur \n\n";


void duplicarImagem(Mat img,string u_predicado,int qtCopias,int incremento);
Mat aplicarFiltro(Mat imagemOriginal, int tipo);



int main(int argc, const char * argv[]) {
    
    Mat imagemEntrada,imagemFiltrada;
    int qtCopias;
    int tipoDeFiltro;
    int inc = 0;
   
    
    if(argc < 5){
        cout <<"ERRO: Voce deve informar uma imagem valida, a quantidade de imagens \n";
        cout <<"a serem duplicadas e o tipo de filtro a ser aplicado e um predicado. Abortando... \n\n";
        
        cout << usage;
        exit(-1);
    }
    
    //lendo a imagem
    imagemEntrada = imread(argv[1]);
    
    if(imagemEntrada.empty()){
        cout <<"Erro: Sem dados na foto. Saindo... \n";
        exit(-1);
    }else{
        cout <<"Carregado: " << argv[1] <<"\n";
    }
    
    qtCopias = atoi(argv[2]);
    tipoDeFiltro = atoi(argv[3]);
    int len = strlen(argv[4]);
    string u_predicado(argv[4],strnlen(argv[4],len));
    
    imagemFiltrada = aplicarFiltro(imagemEntrada, tipoDeFiltro);
    duplicarImagem(imagemFiltrada,u_predicado, qtCopias, inc);
    
    
    return 0;
}




/*********************************************************************
 *                      SECAO DAS FUNCOES                            *
 *********************************************************************/
void duplicarImagem(Mat img,string u_predicado,int qtCopias,int incremento){
    
    if(incremento >= qtCopias){
        cout <<"Processo terminado! \n";
        return;
    }
    
    string predicado = "OUT_";
    string ext = ".jpg";
    ostringstream oss;
    oss << u_predicado << predicado << incremento << ext;
    string filename = oss.str();
    const char *nome = filename.c_str();
    
    bool saved = imwrite(nome,img);
    if(saved){
        cout <<">>Saida: " << nome <<"\n";
    }else{
        cout<<"ATENCAO: erro ao salvar imagem...\n";
    }
    
    duplicarImagem(img,u_predicado, qtCopias, ++incremento);
}









Mat aplicarFiltro(Mat imagemOriginal, int tipo){
    
    int MAX_KERNEL_LENGTH;
    //int DELAY_CAPTION = 1500;
    //int DELAY_BLUR = 100;
    
    Mat img;
    if(tipo == 0){ //nao aplica filtro, somente duplica
        cout <<"Sem filtro..\n";
        img = imagemOriginal;
    }
    
    if(tipo == 1){ //medianblur
        cout <<"MedianBlur ...\n";
        cout <<"Informe o  MAX_KERNEL_LENGTH: "; cin >>  MAX_KERNEL_LENGTH;
        for ( int i = 1; i < MAX_KERNEL_LENGTH; i = i + 2 )
            medianBlur ( imagemOriginal, img, i );
    }
    
    if(tipo == 2){ //bilateral
        cout <<"BilateralBlur... \n";
        cout <<"Informe o  MAX_KERNEL_LENGTH: "; cin >>  MAX_KERNEL_LENGTH;
         for ( int i = 1; i < MAX_KERNEL_LENGTH; i = i + 2 )
             bilateralFilter ( imagemOriginal, img, i, i*2, i/2 );
        
    }if(tipo == 3) {//homogeneous blur
        cout <<"HomogeneousBlur... \n";
        cout <<"Informe o  MAX_KERNEL_LENGTH: "; cin >>  MAX_KERNEL_LENGTH;
        for ( int i = 1; i < MAX_KERNEL_LENGTH; i = i + 2 )
            blur( imagemOriginal, img, Size( i, i ), Point(-1,-1) );
        
    }
    
    
    return img;
}











/*
 
 int len = strlen(pathImagem);
 string pathImg(pathImagem,strnlen(pathImagem, len));
 string fileName;
 if(pathImg.find("/") != string::npos){
 //o caminho informado nao e a pasta padrao
 //pegando o nome da imagem
 int pos = pathImg.find_last_of("/");
 fileName = pathImg.substr(pos+1);
 
 }

 
 
 */
