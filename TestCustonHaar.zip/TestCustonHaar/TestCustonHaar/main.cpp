//
//  main.cpp
//  TestCustonHaar
//
//  Created by Edson  Jr on 29/10/16.
//  Copyright © 2016 Edson  Jr. All rights reserved.
//

#include <iostream>
#include <cstdio>
#include <opencv/cv.h>
#include <opencv2/opencv.hpp>
#include <opencv/cv.h>
#include <opencv2/highgui.hpp>
#include <opencv2/ml.hpp>


using namespace std;
using namespace cv;



int main(int argc, const char * argv[]) {
   
    
    Mat inputImg;
    const char *haarCascade;
    const char *imgName;
   
    
    if(argc < 3){
        cout <<"Erro: Voce devera informar locadl do <haarCascade.xml> e uma imagem de entrada\n";
        exit(-1);
    }
    
    CascadeClassifier objDetectCascade;
    
    //tentando carregar o haarcascade
    if(!objDetectCascade.load(argv[1])){
        cout << "FATAL ERROR: Nao foi possivel carregar cascade xml files. Abortando... \n";
        cout << objDetectCascade.empty() << "\n";
        exit(-1);
    }
    
    //carregando a imagem
    imgName = argv[2];
    inputImg = imread(imgName,CV_LOAD_IMAGE_COLOR);
    
    
    
    //verificando se a imagem nao encontra - se vazia
    if(inputImg.empty()){
        cout << "FATAL ERROR: Sem dados de imagem. Abortando... \n";
        exit(-1);
    }else {
        cout << "Input: " << imgName <<"\n";
    }
    
    
    vector<Rect> faces;
    objDetectCascade.detectMultiScale(inputImg, faces, 1.1, 2, 0|CV_HAAR_SCALE_IMAGE, Size(64, 64));

    //verificando se ha faces na imagem, caso contrario aborta
    if(faces.size() == 0){
        cout <<"ATENCAO: Nao foram detectados objetos na foto. Abortando...\n";
        exit(-1);
    }

    // desenhando circulos nas faces
    for( int i = 0; i < faces.size(); i++ )
    {
        Point center( faces[i].x + faces[i].width*0.5, faces[i].y + faces[i].height*0.5 );
        ellipse( inputImg, center, Size( faces[i].width*0.6, faces[i].height*0.6), 0, 0, 360, Scalar( 255, 0, 255 ), 4, 8, 0 );
    }

    
    imshow( "Detected Face", inputImg );
    waitKey(0);    
    
    
    
    return 0;
}
